# **0x00. AirBnB clone - The console**
