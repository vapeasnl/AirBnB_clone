#!/usr/bin/python3
""" Defines unit tests for the console """
from unittest import TestCase
from console import HBNBCommand


class TestConsole(TestCase):
    """ Test class with method testing console """
    pass
